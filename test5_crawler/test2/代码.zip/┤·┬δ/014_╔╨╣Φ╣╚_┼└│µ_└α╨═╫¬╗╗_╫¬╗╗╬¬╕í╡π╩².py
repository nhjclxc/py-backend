# 当我们在爬虫的时候大部分获取的都是字符串数据类型

# a = '12.34'
# print(type(a))
# 将字符串类型的数据转换为浮点数
# b = float(a)
# print(b)
# print(type(b))


a = 666
print(a)
print(type(a))

b = float(a)
print(b)
print(type(b))
