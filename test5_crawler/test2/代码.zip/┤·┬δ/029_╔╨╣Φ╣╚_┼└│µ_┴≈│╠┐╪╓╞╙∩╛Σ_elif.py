# 在控制台上输入您的成绩分数
# 如果你考了90以上  成绩为优秀
# 如果你考了80以上  成绩为良好
# 如果你考了70以上  成绩为中等
# 如果你考了60以上  成绩为合格
# 否则            成绩为不合格


# score = int(input('请输入您的分数'))

# if score >= 90:
#     print('优秀')
# if score >= 80:
#     print('良好')
# if score >= 70:
#     print('中等')
# if score >= 60:
#     print('及格')
# if score < 60:
#     print('不及格')

# elif
score = int(input('请输入您的成绩'))

if score >= 90:
    print('优秀')
elif score >= 80:
    print('良好')
elif score >= 70:
    print('中等')
elif score >= 60:
    print('及格')
else:
    print('不及格')




