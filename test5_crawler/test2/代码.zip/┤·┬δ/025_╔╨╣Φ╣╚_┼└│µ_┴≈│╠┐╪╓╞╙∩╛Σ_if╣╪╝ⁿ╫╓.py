# if关键字的语句结构
# if 判断条件:
#         代码（如果判断条件为true的时候执行if下面的内容）

age = 17

# 吉多  abc语言
# 如果您的年龄大于18了 那么你就可以开车了
if age > 18:
    print('你可以开车了')

# True代表的是男  False代表的是女
gender = True

if gender == True:
    # if下面的代码 必须是一个tab键 或者四个空格
    print('你是一个男性')


