a = 3
b = 2

# print(a + b)
#
# print(a - b)
#
# print(a * b)
#
# print(a / b)
# # 取整
# print(a // b)
# # 取余
# print(a % b)
# # 指数  幂
# print(a ** b)
#
# print((5 + 1) * 2)

# 扩展
# 字符串的加法 是进行拼接的
# a = '123'
# b = '456'
# print(a + b)

# 在python中 +两端都是字符串才可以进行加法运算
# a = '123'
# b = 456
# # print(a + b)
# print(a + str(b))

# 字符串的乘法 是将字符串重复多少次
a = '我爱你 你爱我 蜜雪冰城甜蜜蜜'
print(a * 3)
