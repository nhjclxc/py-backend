

# a_list = [1,2,3,4,5]
#
# print(a_list)

# 根据下标来删除列表中的元素
# 爬取的数据中 有个别的数据 是我们不想要的 那么我们就可以通过下标的方式来删除
# del a_list[2]
# print(a_list)


# b_list = [1,2,3,4,5]
# print(b_list)
# pop是删除列表中的最后一个元素
# b_list.pop()
#
# print(b_list)


c_list = [1,2,3,4,5]
print(c_list)

# 根据元素来删除列表中的数据
c_list.remove(3)
print(c_list)

