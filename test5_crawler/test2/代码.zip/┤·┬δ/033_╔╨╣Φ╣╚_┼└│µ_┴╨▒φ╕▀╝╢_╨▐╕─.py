

city_list = ['北京','上海','深圳','武汉','西安']

print(city_list)

# 将列表中的元素的值修改
# 可以通过下标来修改，注意列表中的下标是从0开始的
city_list[4] = '大连'
print(city_list)