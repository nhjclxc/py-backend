# 整型转换为字符串   大部分的应用场景

# 整数转换为字符串
# a = 80
# print(type(a))
# # 强制类型转换为字符串的方法是str()
# b = str(a)
# print(b)
# print(type(b))

# 浮点数转换为字符串
# a = 1.2
# print(type(a))
# b = str(a)
# print(b)
# print(type(b))

# 布尔类型转换为字符串
a = True
print(type(a))
b = str(a)
print(b)
print(type(b))

