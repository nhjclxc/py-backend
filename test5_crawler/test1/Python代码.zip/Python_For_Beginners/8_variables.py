greet = "您好，吃了么，"
greet_chinese = greet
greet_english = "Yo what's up, "
greet = greet_english
print(greet + "张三")
print(greet + "李四")
print(greet + "王五")
print(greet_chinese + "张三")
