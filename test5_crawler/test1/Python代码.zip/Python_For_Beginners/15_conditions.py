mood_index = int(input("对象今天的心情指数是："))
if mood_index >= 60:
    print("恭喜，今晚应该可以打游戏，去吧皮卡丘！")
    print("∠( ᐛ 」∠)_")
else:  # mood_index < 60
    print("为了自个儿小命，还是别打了。")