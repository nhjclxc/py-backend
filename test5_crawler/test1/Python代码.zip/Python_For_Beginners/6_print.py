print("Dad!")
print("妈！！")
