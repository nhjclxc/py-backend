import math
print(math.floor(3.5))